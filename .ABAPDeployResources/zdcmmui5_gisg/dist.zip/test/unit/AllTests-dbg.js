sap.ui.define([
	"SYNC/zdcmmui5_gisg/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
